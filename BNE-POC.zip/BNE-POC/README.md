s# COMPILE TO MICROAPP ANGULAR
ng build --prod --output-hashing none --single-bundle true --bundle-styles false  --project login-bne
ng build --prod --output-hashing none --single-bundle true --bundle-styles false  --project app-multibalance


#Install blueblox

npm i @bluebox_dls/angular --registry https://nexus.knightfall.xyz/repository/knightfall/


# BUILD PROJECT
npm build login
npm build multibalance

ng serve