import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { AppComponent } from './app.component';
import { MultibalanceModule } from 'multibalance';
import { BlueboxdlsModule } from '@bluebox_dls/angular';
@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, BlueboxdlsModule, MultibalanceModule],
  providers: [],
  bootstrap: [],
  entryComponents: [AppComponent],
})
export class AppModule {
  constructor(private injector: Injector) {}

  ngDoBootstrap() {
    const login = createCustomElement(AppComponent, { injector: this.injector });
    customElements.define('lib-multibalance', login);
  }
}
