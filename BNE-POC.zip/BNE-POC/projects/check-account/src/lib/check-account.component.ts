import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'check-account',
  templateUrl: './check-account.component.html',
  styleUrls: ['./check-account.component.scss'],
})
export class CheckAccountComponent implements OnInit {
  @Input('env-summary') envSummary;
  @Input('env-balance') envBalance;
  @Input('env-detail') envDetail;
  @Input('title') title;
  constructor() {}

  ngOnInit() {}
}
