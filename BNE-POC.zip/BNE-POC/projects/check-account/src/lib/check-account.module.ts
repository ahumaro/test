import { NgModule } from '@angular/core';
import { CheckAccountComponent } from './check-account.component';
import { ViewComponent } from './components/view/view.component';
import { CommonModule } from '@angular/common';
@NgModule({
  declarations: [CheckAccountComponent, ViewComponent],
  imports: [CommonModule],
  exports: [CheckAccountComponent],
})
export class CheckAccountModule {}
