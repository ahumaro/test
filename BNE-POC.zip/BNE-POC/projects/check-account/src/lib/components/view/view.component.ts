import { Component, OnInit, Input } from '@angular/core';
import { CheckAccountService } from '../../services/check-account.service';
@Component({
  selector: 'view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss'],
})
export class ViewComponent implements OnInit {
  body = {};
  checkingAccounts;

  mapCheckAccount = [];

  @Input('env-summary') envSummary;
  @Input('env-balance') envBalance;
  @Input('env-detail') envDetail;
  @Input('title') title;
  constructor(public httpCheck: CheckAccountService) {}

  ngOnInit() {
    this.httpCheck.requestSummary(this.body, this.envSummary).subscribe((response: any) => {
      this.httpCheck.requestSummary(this.body, this.envBalance).subscribe((response: any) => {
        this.checkingAccounts = response.accounts.checkinAccount;
        this.checkingAccounts.forEach(element => {
          this.mapCheckAccount.push({
            title: element.accountBalance.accountTitleName,
            balance: element.accountBalance.currentBalanceAmount,
            currency: element.accountBalance.currencyCode,
          });
        });
      });
    });
    this.httpCheck.requestDetail(this.body, this.envSummary).subscribe((respons: any) => {});
  }
}
