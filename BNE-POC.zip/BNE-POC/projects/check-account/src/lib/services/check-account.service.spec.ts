import { TestBed } from '@angular/core/testing';

import { CheckAccountService } from './check-account.service';

describe('CheckAccountService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CheckAccountService = TestBed.get(CheckAccountService);
    expect(service).toBeTruthy();
  });
});
