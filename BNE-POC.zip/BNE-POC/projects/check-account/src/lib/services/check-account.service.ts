import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class CheckAccountService {
  constructor(public http: HttpClient) {}

  requestSummary(body, env) {
    const newheaders = new HttpHeaders({
      ChannelId: '17091201',
      uuid: 'bd1a585f-bdbe-4bu1-uid7-18a08s34t001',
      'Content-Type': 'application/json',
      sid: ' 5b5316c1-s384-4965-i74d-18a08s34t001',
      client_id: '1974440',
      Accept: 'application/json',
      Authorization: '13',
      'Accept-Language': 'es',
    });
    return this.http.post(env, body, { headers: newheaders });
  }

  requestBalance(body, env) {
    const newheaders = new HttpHeaders({
      ChannelId: '17091201',
      uuid: 'bd1a585f-bdbe-4bu1-uid7-18a08s34t001',
      'Content-Type': 'application/json',
      sid: ' 5b5316c1-s384-4965-i74d-18a08s34t001',
      client_id: '1974440',
      Accept: 'application/json',
      Authorization: '13',
      'Accept-Language': 'es',
    });
    return this.http.post(env, body, { headers: newheaders });
  }

  requestDetail(body, env) {
    const newheaders = new HttpHeaders({
      ChannelId: '17091201',
      uuid: 'bd1a585f-bdbe-4bu1-uid7-18a08s34t001',
      'Content-Type': 'application/json',
      sid: ' 5b5316c1-s384-4965-i74d-18a08s34t001',
      client_id: '1974440',
      Accept: 'application/json',
      Authorization: '13',
      'Accept-Language': 'es',
    });
    return this.http.post(env, body, { headers: newheaders });
  }
}
