/*
 * Public API Surface of check-account
 */
export * from './lib/check-account.module';
