import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'credit-account',
  templateUrl: './credit-account.component.html',
  styleUrls: ['./credit-account.component.scss'],
})
export class CreditAccountComponent implements OnInit {
  @Input('env-summary') envSummary;
  @Input('env-balance') envBalance;
  @Input('env-detail') envDetail;
  @Input('title') title;
  constructor() {}

  ngOnInit() {}
}
