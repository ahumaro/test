import { NgModule } from '@angular/core';
import { CreditAccountComponent } from './credit-account.component';
import { ViewComponent } from './components/view/view.component';
import { CommonModule } from '@angular/common';
@NgModule({
  declarations: [CreditAccountComponent, ViewComponent],
  imports: [CommonModule],
  exports: [CreditAccountComponent],
})
export class CreditAccountModule {}
