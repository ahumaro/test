import { TestBed } from '@angular/core/testing';

import { CreditAccountService } from './credit-account.service';

describe('CreditAccountService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreditAccountService = TestBed.get(CreditAccountService);
    expect(service).toBeTruthy();
  });
});
