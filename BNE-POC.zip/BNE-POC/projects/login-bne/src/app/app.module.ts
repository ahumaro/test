import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';
import { LoginComponent } from './components/login/login.component';
import { createCustomElement } from '@angular/elements';
import { BlueboxdlsModule } from '@bluebox_dls/angular';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginService } from './services/login.service';
@NgModule({
  declarations: [LoginComponent],
  imports: [BrowserModule, BlueboxdlsModule, FormsModule, HttpClientModule],
  providers: [LoginService],
  bootstrap: [],
  entryComponents: [LoginComponent],
})
export class AppModule {
  constructor(private injector: Injector) {}

  ngDoBootstrap() {
    const login = createCustomElement(LoginComponent, { injector: this.injector });
    customElements.define('login-bne', login);
  }
}
