import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'login-bne',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  user: string;
  access: string;
  disabledButton: boolean;
  step: number;
  challenge;
  challengeUser;
  errorLabel;
  error;

  @Output('login') loginstatus = new EventEmitter();
  @Input('login-environment') loginEnvironment: string;
  @Input('challenge-environment') challengeEnvironment: string;
  @Input('channel-id') channelId: string;

  constructor(private loginService: LoginService) {}

  ngOnInit() {
    this.step = 1;
    this.error = false;
  }

  sendUser() {
    this.disabledButton = true;
    const body = {
      sessionRequired: true,
      customerCredentials: {
        customerId: this.user,
        legalRepresentativeId: '21',
        password: this.access,
        encryptionType: '',
        language: 'es',
        clientIp: '1.1.1.1',
        data: '',
      },
    };
    this.loginService.requestUser(body, this.loginEnvironment, this.channelId).subscribe(
      res => {
        this.loginService.requestChallenge(this.user, this.challengeEnvironment, this.channelId).subscribe(
          (response: any) => {
            this.challenge = response.challengeCode;
            this.disabledButton = false;
            this.step++;
            this.error = false;
          },
          error => {
            console.log('error');
          }
        );
      },
      error => {
        this.error = true;
        this.errorLabel = 'Error en servidor';
        this.disabledButton = false;
      }
    );
  }

  validateUser() {
    this.disabledButton = true;
    this.loginService.validateChallenge(this.challengeUser, this.challengeEnvironment, this.channelId).subscribe(
      validateUser => {
        this.disabledButton = false;
        this.loginstatus.emit({ logedIn: true });
      },
      error => {
        this.disabledButton = false;
        this.loginstatus.emit({ logedIn: false });
      }
    );
  }
}
