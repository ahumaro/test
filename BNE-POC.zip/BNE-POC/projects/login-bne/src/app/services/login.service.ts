import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  constructor(public http: HttpClient) {}

  requestUser(body, env, cid) {
    const newheaders = new HttpHeaders({
      ChannelId: cid,
      uuid: cid,
      'Content-Type': 'application/json',
      sid: '123456789',
      client_id: 'cb790',
      Accept: 'application/json',
    });
    return this.http.post(env + '/channels/bne/authenticate/login', body, { headers: newheaders });
  }

  requestChallenge(user, env, cid) {
    const newheaders = new HttpHeaders({
      ChannelId: cid,
      uuid: cid,
      'Content-Type': 'application/json',
      sid: '123456789',
      client_id: 'cb790',
      Accept: 'application/json',
    });
    const body = {
      customer: {
        customerId: user,
        legalRepresentativeId: '98',
      },
    };
    return this.http.post(env + '/channels/bne/authorization/challenge/retrieve', body, { headers: newheaders });
  }

  validateChallenge(changeUser, env, cid) {
    const newheaders = new HttpHeaders({
      ChannelId: cid,
      uuid: cid,
      'Content-Type': 'application/json',
      sid: '123456789',
      client_id: 'cb790',
      Accept: 'application/json',
    });
    const body = {
      challengeType: 'LOGIN',
      transaction: 'LOGIN',
      validationCode: changeUser,
    };

    return this.http.post(env + '/channels/bne/authorization/challenge/authenticate', body, {
      headers: newheaders,
    });
  }
}
