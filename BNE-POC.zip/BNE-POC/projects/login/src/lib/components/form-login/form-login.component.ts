import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { LoginBneService } from '../../services/login-bne.service';
@Component({
  selector: 'login-bne',
  templateUrl: './form-login.component.html',
  styleUrls: ['./form-login.component.scss'],
})
export class FormLoginComponent implements OnInit {
  user: string;
  access: string;
  disabledButton: boolean;
  step: number;
  challenge;
  challengeUser;
  errorLabel;
  error;

  @Output() loginstatus = new EventEmitter();
  @Input('login-environment') loginEnvironment;
  @Input('challenge-environment') challengeEnvironment;
  @Input('validate-challenge-user') validateChallengeEnvironment;
  @Input('channel-id') channelId;

  constructor(private loginService: LoginBneService) {}

  ngOnInit() {
    this.step = 1;
    this.error = false;
  }

  sendUser() {
    this.disabledButton = true;
    const body = {
      sessionRequired: true,
      customerCredentials: {
        customerId: this.user,
        legalRepresentativeId: '21',
        password: this.access,
        encryptionType: '',
        language: 'es',
        clientIp: '1.1.1.1',
        data: '',
      },
    };
    this.loginService.requestUser(body, this.loginEnvironment, this.channelId).subscribe(
      res => {
        this.loginService.requestChallenge(this.user, this.challengeEnvironment, this.channelId).subscribe(
          (response: any) => {
            this.challenge = response.challengeCode;
            this.disabledButton = false;
            this.step++;
            this.error = false;
          },
          error => {
            console.log('error');
          }
        );
      },
      error => {
        this.error = true;
        this.errorLabel = 'Error en servidor';
        this.disabledButton = false;
      }
    );
  }

  validateUser() {
    this.disabledButton = true;
    this.loginService
      .validateChallenge(this.challengeUser, this.validateChallengeEnvironment, this.channelId)
      .subscribe(
        validateUser => {
          this.disabledButton = false;
          this.loginstatus.emit({ logedIn: true, user: this.user });
        },
        error => {
          this.disabledButton = false;
          this.loginstatus.emit({ logedIn: false });
        }
      );
  }
}
