import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'online-comp',
  templateUrl: './online.component.html',
  styleUrls: ['./online.component.css'],
})
export class OnlineComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
