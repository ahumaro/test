import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  /**
   * If user is in personal screen to write password
   */
  personal = true;

  /**
   * The constructor for login component
   */
  constructor() {}

  /**
   * Lifecycle for Login component to enter TDC client.
   */
  ngOnInit() {}
}
