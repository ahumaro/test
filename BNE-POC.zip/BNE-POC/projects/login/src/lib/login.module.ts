import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login.component';
import { FormLoginComponent } from './components/form-login/form-login.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BlueboxdlsModule } from '@bluebox_dls/angular';
@NgModule({
  declarations: [LoginComponent, FormLoginComponent],
  imports: [FormsModule, HttpClientModule, CommonModule, BlueboxdlsModule],
  exports: [FormLoginComponent],
})
export class LoginModule {}
