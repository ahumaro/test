import { TestBed } from '@angular/core/testing';

import { LoginBneService } from './login-bne.service';

describe('LoginBneService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LoginBneService = TestBed.get(LoginBneService);
    expect(service).toBeTruthy();
  });
});
