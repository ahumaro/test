import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class LoginBneService {
  constructor(public http: HttpClient) {}

  requestUser(body, envlogin, cid) {
    const newheaders = new HttpHeaders({
      ChannelId: cid,
      uuid: cid,
      'Content-Type': 'application/json',
      sid: '123456789',
      client_id: 'cb790',
      Accept: 'application/json',
    });
    return this.http.post(envlogin, body, { headers: newheaders });
  }

  requestChallenge(user, envChallenge, cid) {
    const newheaders = new HttpHeaders({
      ChannelId: cid,
      uuid: cid,
      'Content-Type': 'application/json',
      sid: '123456789',
      client_id: 'cb790',
      Accept: 'application/json',
    });
    const body = {
      customer: {
        customerId: user,
        legalRepresentativeId: '98',
      },
    };
    return this.http.post(envChallenge, body, { headers: newheaders });
  }

  validateChallenge(changeUser, envValidateChallenge, cid) {
    const newheaders = new HttpHeaders({
      ChannelId: cid,
      uuid: cid,
      'Content-Type': 'application/json',
      sid: '123456789',
      client_id: 'cb790',
      Accept: 'application/json',
    });
    const body = {
      challengeType: 'LOGIN',
      transaction: 'LOGIN',
      validationCode: changeUser,
    };

    return this.http.post(envValidateChallenge, body, {
      headers: newheaders,
    });
  }
}
