import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'master-account',
  templateUrl: './master-account.component.html',
  styleUrls: ['./master-account.component.scss'],
})
export class MasterAccountComponent implements OnInit {
  @Input('env-summary') envSummary;
  @Input('env-balance') envBalance;
  @Input('env-detail') envDetail;
  @Input('title') title;
  constructor() {}

  ngOnInit() {}
}
