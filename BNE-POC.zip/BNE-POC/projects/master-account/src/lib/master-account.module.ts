import { NgModule } from '@angular/core';
import { MasterAccountComponent } from './master-account.component';
import { ViewComponent } from './components/view/view.component';
import { CommonModule } from '@angular/common';
@NgModule({
  declarations: [MasterAccountComponent, ViewComponent],
  imports: [CommonModule],
  exports: [MasterAccountComponent],
})
export class MasterAccountModule {}
