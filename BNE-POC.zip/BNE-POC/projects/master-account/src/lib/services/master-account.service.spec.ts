import { TestBed } from '@angular/core/testing';

import { MasterAccountService } from './master-account.service';

describe('MasterAccountService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MasterAccountService = TestBed.get(MasterAccountService);
    expect(service).toBeTruthy();
  });
});
