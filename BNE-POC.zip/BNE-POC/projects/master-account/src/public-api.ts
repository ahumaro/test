/*
 * Public API Surface of master-account
 */
export * from './lib/master-account.module';
