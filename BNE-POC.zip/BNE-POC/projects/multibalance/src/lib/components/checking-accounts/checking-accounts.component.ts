import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'lib-checking-accounts',
  templateUrl: './checking-accounts.component.html',
  styleUrls: ['./checking-accounts.component.scss'],
})
export class CheckingAccountsComponent implements OnInit {
  @Input() accounts;
  constructor() {}

  ngOnInit() {}
}
