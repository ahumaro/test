import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterAccountsComponent } from './master-accounts.component';

describe('MasterAccountsComponent', () => {
  let component: MasterAccountsComponent;
  let fixture: ComponentFixture<MasterAccountsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MasterAccountsComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterAccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
