import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'lib-master-accounts',
  templateUrl: './master-accounts.component.html',
  styleUrls: ['./master-accounts.component.scss'],
})
export class MasterAccountsComponent implements OnInit {
  @Input() accounts;
  constructor() {}

  ngOnInit() {}
}
