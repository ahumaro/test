import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultibalanceComponent } from './multibalance.component';

describe('MultibalanceComponent', () => {
  let component: MultibalanceComponent;
  let fixture: ComponentFixture<MultibalanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MultibalanceComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultibalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
