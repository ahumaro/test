import { Component, OnInit } from '@angular/core';
import { MultibalanceService } from '../lib/services/multibalance.service';
import { Router } from '@angular/router';
@Component({
  selector: 'lib-multibalance',
  templateUrl: './multibalance.component.html',
  styleUrls: ['./multibalance.component.scss'],
})
export class MultibalanceComponent implements OnInit {
  accounts;
  accountsDetail;

  masterAccounts = {
    name: '',
    lastActivityDate: '',
    currentBalanceAmount: '',
    currencyCode: '',
  };

  checkingAccounts = {
    name: '',
    clabe: '',
    currentBalanceAmount: '',
  };

  arrayMasterAccounts = [];
  arrayCheckingAccounts = [];

  constructor(private multibalanceService: MultibalanceService, private router: Router) {}

  ngOnInit() {
    const user = localStorage.getItem('dataSource');
    if (true) {
      const bodysummary = {
        accountsCountPerAccountType: 10,
        customerId: user,
        legalRepresentativeId: '16',
      };

      const bodyMultibalance = {
        accountsDetail: [
          {
            accountType: 'MASTER_ACCOUNT',
            accountsNumber: '7856616',
            branchCode: null,
          },
          {
            accountType: 'MASTER_ACCOUNT',
            accountsNumber: '7856616',
            branchCode: null,
          },
          {
            accountType: 'CHECKING',
            accountsNumber: '7856616',
            branchCode: null,
          },
        ],
      };

      // this.multibalanceService.requestSummary(bodysummary).subscribe(response => {}, error => {});

      this.multibalanceService.requestMultibalance(bodyMultibalance).subscribe(
        (response: any) => {
          this.resetData();
          this.masterAccounts.name = response.accounts.masterAccount[0].accountBalance.accountTitleName;
          bodyMultibalance.accountsDetail.forEach(e => {
            const bodyDetail = {
              accountType: e.accountType,
              accountNumber: e.accountsNumber,
              branchCode: e.branchCode,
            };
            this.multibalanceService.requestDetail(bodyDetail).subscribe(
              (detail: any) => {
                switch (bodyDetail.accountType) {
                  case 'MASTER_ACCOUNT':
                    this.masterAccounts.lastActivityDate = detail.accountsData.masterAccount[0].lastActivityDate;
                    this.masterAccounts.currentBalanceAmount =
                      detail.accountsData.masterAccount[0].accountBalanceData.currentBalanceAmount;
                    this.arrayMasterAccounts.push(this.masterAccounts);
                    break;
                  case 'CHECKING':
                    this.checkingAccounts.clabe = detail.accountsData.checkingAccount[0].clabeNumber;
                    this.checkingAccounts.currentBalanceAmount =
                      detail.accountsData.checkingAccount[0].accountBalanceData.currentBalanceAmount;
                    this.arrayCheckingAccounts.push(this.checkingAccounts);
                    break;
                }
              },
              error => {}
            );
          });
        },
        error => {}
      );
    } else {
      this.router.navigate(['/login']);
    }
  }

  resetData() {
    this.masterAccounts = {
      name: '',
      lastActivityDate: '',
      currentBalanceAmount: '',
      currencyCode: '',
    };

    this.checkingAccounts = {
      name: '',
      clabe: '',
      currentBalanceAmount: '',
    };
  }
}
