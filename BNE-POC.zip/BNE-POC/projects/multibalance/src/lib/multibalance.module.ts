import { NgModule } from '@angular/core';
import { MultibalanceComponent } from './multibalance.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BlueboxdlsModule } from '@bluebox_dls/angular';
import { MasterAccountsComponent } from './components/master-accounts/master-accounts.component';
import { CheckingAccountsComponent } from './components/checking-accounts/checking-accounts.component';
import { MultibalanceService } from './services/multibalance.service';
@NgModule({
  declarations: [MultibalanceComponent, MasterAccountsComponent, CheckingAccountsComponent],
  imports: [HttpClientModule, CommonModule, BlueboxdlsModule],
  exports: [MultibalanceComponent],
  providers: [MultibalanceService],
})
export class MultibalanceModule {}
