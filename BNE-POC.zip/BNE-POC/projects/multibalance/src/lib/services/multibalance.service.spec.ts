import { TestBed } from '@angular/core/testing';

import { MultibalanceService } from './multibalance.service';

describe('MultibalanceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MultibalanceService = TestBed.get(MultibalanceService);
    expect(service).toBeTruthy();
  });
});
