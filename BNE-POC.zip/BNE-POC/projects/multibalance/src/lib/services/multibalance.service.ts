import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class MultibalanceService {
  constructor(public http: HttpClient) {}

  requestMultibalance(body) {
    const newheaders = new HttpHeaders({
      ChannelId: '17091201',
      uuid: 'bd1a585f-bdbe-4bu1-uid7-18a08s34t001',
      'Content-Type': 'application/json',
      sid: ' 5b5316c1-s384-4965-i74d-18a08s34t001',
      client_id: '1974440',
      Accept: 'application/json',
      Authorization: '13',
      'Accept-Language': 'es',
    });
    return this.http.post(
      'http://18.222.84.90:8080/mafch-d-bne-account-multibalance-mobile/api/private/v1/channels/bne/accounts/balance',
      body,
      { headers: newheaders }
    );
  }

  requestDetail(body) {
    const newheaders = new HttpHeaders({
      ChannelId: '17091201',
      uuid: 'bd1a585f-bdbe-4bu1-uid7-18a08s34t001',
      'Content-Type': 'application/json',
      sid: ' 5b5316c1-s384-4965-i74d-18a08s34t001',
      client_id: '1974440',
      Accept: 'application/json',
      Authorization: '13',
      'Accept-Language': 'es',
    });
    return this.http.post(
      'http://18.222.84.90:8080/mafch-d-bne-account-multibalance-mobile/api/private/v1/channels/bne/accounts/balances/detail',
      body,
      { headers: newheaders }
    );
  }

  requestSummary(body) {
    const newheaders = new HttpHeaders({
      ChannelId: '17091201',
      uuid: 'bd1a585f-bdbe-4bu1-uid7-18a08s34t001',
      'Content-Type': 'application/json',
      sid: ' 5b5316c1-s384-4965-i74d-18a08s34t001',
      client_id: '1974440',
      Accept: 'application/json',
      Authorization: '13',
      'Accept-Language': 'es',
    });
    return this.http.post(
      'http://18.222.84.90:8080/mafch-d-bne-account-multibalance-mobile/api/private/v1/channels/bne/accounts/balances/summary',
      body,
      { headers: newheaders }
    );
  }
}
