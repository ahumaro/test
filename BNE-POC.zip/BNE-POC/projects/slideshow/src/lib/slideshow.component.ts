import { Component, OnInit, Input } from '@angular/core';
import { Entry } from 'contentful';
import { SlideshowService } from './slideshow.service';

@Component({
  selector: 'citi-slideshow',
  template: `
  <mdb-carousel class="carousel slide carousel-fade" [animation]="'fade'">
    <ng-container *ngFor="let image of slideshowImages">
    <mdb-carousel-item *ngIf="image.fields.enabled && (image.fields.segment == 'ALL' || image.fields.segment == segment)">
      <div class="view w-100">
        <img class="d-block w-100" src="{{image.fields.image.fields.file.url}}" alt="First slide">
        <div class="mask rgba-black-light waves-light" mdbWavesEffect></div>
      </div>
      <div class="carousel-caption">
        <h3 class="h3-responsive">{{image.fields.title}}</h3>
        <p>{{image.fields.subtitle}}</p>
      </div>
    </mdb-carousel-item>
    </ng-container>
  </mdb-carousel>

  <!--ul class="u-listReset">
    <ng-container *ngFor="let image of slideshowImages">
      <li *ngIf="image.fields.enabled && (image.fields.segment == 'ALL' || image.fields.segment == segment)">
        {{ image.fields.name }}
      </li>
    </ng-container>
  </ul-->
  `,
  styles: []
})
export class SlideshowComponent implements OnInit {
  slideshowImages: Entry<any>[] = [];
  @Input('segment') segment;

  constructor(private slideshowService: SlideshowService) { }

  ngOnInit() {
    this.slideshowService.getSlideshowImages()
    .then(slideshowImages => { this.slideshowImages = slideshowImages;
          console.log(slideshowImages); console.log(this.segment);});
  }

}
