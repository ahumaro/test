import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SlideshowComponent } from './slideshow.component';
import { CarouselModule, WavesModule } from 'angular-bootstrap-md'

import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [SlideshowComponent],
  imports: [CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    MDBBootstrapModule.forRoot(),
    FormsModule,
    CarouselModule,
    WavesModule
  ],
  exports: [SlideshowComponent],
  schemas: [ NO_ERRORS_SCHEMA ]
})
export class SlideshowModule { }
