import { Injectable } from '@angular/core';
import { createClient, Entry } from 'contentful';

const CONFIG = {
  space: 'r8ds3hc0zyxv',
  accessToken: 'ognYIH8MrxpuqC3JQ7Mb863QV-tD516A_z2_3LNPIZ0',

  contentTypeIds: {
    model: 'slideshow-Item'
  }
}

@Injectable({
  providedIn: 'root'
})
export class SlideshowService {
  private cdaClient = createClient({
    space: CONFIG.space,
    accessToken: CONFIG.accessToken
  });

  constructor() {}

  getSlideshowImages(query?: object): Promise<Entry<any>[]> {
    return this.cdaClient.getEntries(Object.assign({
      content_type: CONFIG.contentTypeIds.model
    }, query))
    .then(res => res.items);
  }
}
