/*
 * Public API Surface of slideshow
 */

export * from './lib/slideshow.service';
export * from './lib/slideshow.component';
export * from './lib/slideshow.module';
