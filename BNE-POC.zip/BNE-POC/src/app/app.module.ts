import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LoginModule } from 'login';
import { MultibalanceModule } from 'multibalance';
import { CheckAccountModule } from 'check-account';
import { MasterAccountModule } from 'master-account';
import { CreditAccountModule } from 'credit-account';
import { SlideshowModule } from 'slideshow';
import { BlueboxdlsModule } from '@bluebox_dls/angular';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './views/login/login.component';
import { MultibalanceComponent } from './views/multibalance/multibalance.component';
import { LandingComponent } from './landing/landing.component';
@NgModule({
  declarations: [AppComponent, LoginComponent, MultibalanceComponent, LandingComponent],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    LoginModule,
    BlueboxdlsModule,
    MultibalanceModule,
    CheckAccountModule,
    MasterAccountModule,
    CreditAccountModule,
    SlideshowModule
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
