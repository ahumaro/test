import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-multibalance',
  templateUrl: './multibalance.component.html',
  styleUrls: ['./multibalance.component.scss'],
})
export class MultibalanceComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit() {}

  logout() {
    localStorage.removeItem('dataSource');
    this.router.navigate(['/login']);
  }
}
